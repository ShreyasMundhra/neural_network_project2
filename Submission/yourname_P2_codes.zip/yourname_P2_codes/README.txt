Please copy the ImageData in this directory in order to preprocess and generate the Training and Testing data for CNN.
