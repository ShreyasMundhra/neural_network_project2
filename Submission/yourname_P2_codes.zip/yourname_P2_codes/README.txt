Please copy the ImageData in this directory in order to generate the Training and Testing data for CNN.
